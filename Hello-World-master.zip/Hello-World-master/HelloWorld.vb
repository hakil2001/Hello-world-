Module HelloWorld
   Sub Main( )
      System.Console.WriteLine("Hello world!")
   End Sub
End Module
