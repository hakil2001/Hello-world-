fprintf ( 1, 'Hello, world!' );

quit
