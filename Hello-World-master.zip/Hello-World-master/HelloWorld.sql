SELECT 'Hello World';
PRINT 'Hello World';
