#include <iostream>
using namespace std;

int main()
{
    cout <<"\nHello World"<< endl;
    return 0;
}
