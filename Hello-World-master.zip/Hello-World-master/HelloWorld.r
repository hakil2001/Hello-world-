variable <- "Hello World"
print (variable)

