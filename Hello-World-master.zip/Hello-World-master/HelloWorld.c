#include<stdio.h>

int main(void)
{
  printf("Hello, world!");
  return 0;
}
