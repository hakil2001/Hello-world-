void main() {
    print('hello world');
}